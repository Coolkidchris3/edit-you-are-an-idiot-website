var cues = [
    {start: 0.040, stop: 0.474, word: "you"},
    {start: 0.580, stop: 0.860, word: "are"},
    {start: 0.860, stop: 1.013, word: "an"},
    {start: 1.069, stop: 1.672, word: "idiot"},
    
    {start: 1.945, stop: 2.112, word: "ah"},
    {start: 2.234, stop: 2.566, word: "haha"},
    {start: 2.593, stop: 2.734, word: "ha"},
    {start: 2.791, stop: 2.936, word: "ha"},
    {start: 2.994, stop: 3.131, word: "ha"},
    {start: 3.207, stop: 3.802, word: "aha"},
    
    {start: 3.871, stop: 3.989, word: "ha"},
    {start: 4.062, stop: 4.207, word: "ha"},
    {start: 4.264, stop: 4.397, word: "ha"},
    
    {start: 4.494, stop: 4.883, word: "ha"}
];