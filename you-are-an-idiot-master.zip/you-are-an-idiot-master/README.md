# You Are An Idiot

[See the thing](http://rodneyrehm.github.io/you-are-an-idiot/)

I'd ask you not to be offended by the title, but I guess the whole point of this thing is to "offend". *I'll* only use this in humorous ways - I hope you will, too.

This thing is not my invention. It just bugged me that the [original](http://youareanidiot.org/) was a Fash site. I "recreated" the thing mostly to have something to test `<audio>` (and `TextTrack`). The MP3 audio file came from [http://shane-o.com/sound-drops/163-idiot-drop](http://shane-o.com/sound-drops/163-idiot-drop).

